export const categories = [
  { id: 1, type: "Aws" },
  { id: 2, type: "CI/CD" },
  { id: 3, type: "GCP" },
  { id: 4, type: "Jenkins" },
  { id: 5, type: "Chef" },
  { id: 6, type: "Azure" },
  { id: 7, type: "Docker" },
  { id: 8, type: "Kubernetes" },
];
